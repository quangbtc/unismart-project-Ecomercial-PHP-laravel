@extends('layouts.admin')
@section('content')
    <div id="content" class="container-fluid">
      <div class="alert alert-danger">Bạn không được phép truy cập vào nội dung này</div>
    </div>
@endsection
