  <div class="sidebar fl-left">
        <div class="section" id="category-product-wp">
            <div class="section-head">
                <h3 class="section-title">Danh mục Sản phẩm</h3>
            </div>
            <div class="secion-detail">
                <ul class="list-item">
                   
                        <?php $__currentLoopData = $parent_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate_parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('client.product.category.list',['slug'=>$cate_parent->slug,'id'=>$cate_parent->id])); ?>" title=""><?php echo e($cate_parent->cat_title); ?></a>
                               <?php echo $__env->make('client.inc.menu_child_product',['cate_parent'=>$cate_parent], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                            
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </ul>
            </div>
        </div>
         <div class="section" id="selling-wp">
                <div class="section-head">
                    <h3 class="section-title">Sản phẩm mới nhất</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php if($new_products): ?>
                        <?php $__currentLoopData = $new_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <li class="clearfix">
                            <a href="<?php echo e(route('client.product.detail',['slug'=>$product->slug,'id'=>$product->id])); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e(url("$product->thumb")); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="<?php echo e(route('client.product.detail',['slug'=>$product->slug,'id'=>$product->id])); ?>" title="" class="product-name"><?php echo e($product->title); ?></a>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($product->sale_price,'0','','.').' đ'); ?></span>
                                    <span class="old"><?php echo e(number_format($product->old_price,'0','','.').' đ'); ?></span>
                                </div>
                                <a href="<?php echo e(route('cart.add',$product->id)); ?>" title="" class="buy-now">Mua ngay</a>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                       
                       
                    </ul>
                </div>
            </div>
        <div class="section" id="banner-wp">
            <div class="section-detail">
                <a href="?page=detail_blog_product" title="" class="thumb">
                    <img src="<?php echo e(asset('client/images/banner.png')); ?>" alt="">
                </a>
            </div>
        </div>
    </div>
<?php /**PATH /Applications/MAMP/htdocs/unismart.com/resources/views/client/inc/sidebar_product.blade.php ENDPATH**/ ?>