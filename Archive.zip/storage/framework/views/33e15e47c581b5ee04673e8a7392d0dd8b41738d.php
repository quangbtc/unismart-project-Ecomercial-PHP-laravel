<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="cart-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Giỏ hàng</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div id="wrapper" class="wp-inner clearfix">
            <div class="section" id="info-cart-wp">
                <div class="section-detail table-responsive">
                    <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(Cart::count() > 0): ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <td>STT</td>
                                        <td>Mã sản phẩm</td>
                                        <td>Ảnh sản phẩm</td>
                                        <td>Tên sản phẩm</td>
                                        <td>Giá sản phẩm</td>
                                        <td>Số lượng</td>
                                        <td colspan="2">Thành tiền</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td>HCA00031</td>
                                            <td>
                                                <a href="" title="" class="thumb">
                                                    <img src="<?php echo e(url($row->options->thumbnail)); ?>" alt="">
                                                </a>
                                            </td>
                                            <td>
                                                <a href="" title="" class="name-product"><?php echo e($row->name); ?></a>
                                            </td>
                                            <td><?php echo e(number_format($row->price, 0, '', '.') . ' đ'); ?></td>
                                            <td>
                                                <input type="number" min="1" name="qty[<?php echo e($row->rowId); ?>]"
                                                    value="<?php echo e($row->qty); ?>" class="num-order">
                                            </td>
                                            <td><?php echo e(number_format($row->total, 0, '', '.') . ' đ'); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('cart.remove', $row->rowId)); ?>" title=""
                                                    class="del-product"><i class="fa fa-trash-o"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="7">
                                            <div class="clearfix">
                                                <p id="total-price" class="fl-right">Tổng giá:
                                                    <span><?php echo e(Cart::total()); ?></span>
                                                </p>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="7">
                                            <div class="clearfix">
                                                <div class="fl-right">
                                                    <input type="submit" name="btn_update" value="Cập nhật giỏ hàng"
                                                        class="btn btn-success">

                                                    <a href="<?php echo e(route('cart.checkout')); ?>" title=""
                                                        id="checkout-cart">Thanh toán</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <div class="section" id="action-cart-wp">
                <?php if(Cart::count() > 0): ?>
                    <div class="section-detail">
                        <p class="title">Click vào <span>“Cập nhật giỏ hàng”</span> để cập nhật số lượng. Nhập vào số lượng
                            <span>0</span> để xóa sản phẩm khỏi giỏ hàng. Nhấn vào thanh toán để hoàn tất mua hàng.
                        </p>
                        <a href="<?php echo e(route('client.product.index')); ?>" title="" id="buy-more">Mua tiếp</a><br />
                        <a href="<?php echo e(route('cart.destroy')); ?>" title="" id="delete-cart">Xóa giỏ hàng</a>
                    </div>
                <?php else: ?>
                    <div class="alert alert-success">Không có sản phẩm trong giỏ hàng</div>
                <?php endif; ?>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/unismart.com/resources/views/client/cart/show.blade.php ENDPATH**/ ?>