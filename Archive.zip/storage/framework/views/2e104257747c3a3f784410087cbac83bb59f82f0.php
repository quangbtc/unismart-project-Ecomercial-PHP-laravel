<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách đơn hàng</h5>
                <div class="form-search form-inline">
                    <form action="<?php echo e(route('order.list')); ?>" method='get'>
                        <input type="text" class="form-control form-search" name='keyword'
                            value='<?php echo e(request()->input('keyword')); ?>' placeholder="Tìm kiếm">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="analytic">
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'success'])); ?>" class="text-primary">Đã giao hàng
                    
                    <span class="text-muted">(<?php echo e($count[0]); ?>)</span></a>

                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'delivering'])); ?>" class="text-primary">Đang giao
                        hàng
                        <span class="text-muted">(<?php echo e($count[2]); ?>)</span></a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'processing'])); ?>" class="text-primary">Chờ thanh
                        toán
                        <span class="text-muted">(<?php echo e($count[1]); ?>)</span></a>

                </div>
                <form action="<?php echo e(route('order.action')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-action form-inline py-3">
                        <select class="form-control mr-1" id="" name='act'>
                            <option value=''>Chọn</option>
                            <?php $__currentLoopData = $list_act; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                        <input type="submit" name="btn-apply" value="Áp dụng" class="btn btn-primary">
                    </div>
                    <table class="table table-striped table-checkall">
                        <thead class="thead-dark">
                            <tr>
                                <th>
                                    <input type="checkbox" name="checkall">
                                </th>
                                <th scope="col">#</th>
                                <th scope="col">Mã đơn hàng</th>
                                <th scope="col">Tên khách hàng</th>
                                <th scope="col">Tổng tiền</th>
                                <th scope="col">Thanh toán</th>
                                <th scope="col">Trạng thái</th>
                                <th scope="col">Ngày đặt hàng</th>
                                <th scope="col">Tác vụ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($orders->count() > 0): ?>
                                <?php
                                    $t = 0;
                                ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $t++;
                                    ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name='list_check[]' value='<?php echo e($order->id); ?>'>
                                        </td>
                                        <th scope="row"><?php echo e($t); ?></th>
                                        <td><?php echo e($order->code); ?></td>
                                        <td><?php echo e($order->customer->full_name); ?></td>
                                        <td><?php echo e(number_format($order->total,0,'','.').' đ'); ?></td>
                                        <td><?php echo e($order->payment); ?></td>
                                        <td class="badge <?php echo e($order->status=='Thành công'?'badge-success':''); ?>

                                            <?php echo e($order->status=='Chờ xử lý'?'badge-warning':''); ?>

                                            <?php echo e($order->status=='Đang giao hàng'?'badge-primary':''); ?>

                                        "><?php echo e($order->status); ?></td>
                                        <td><?php echo e($order->created_at); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('order.detail',$order->id)); ?>"
                                                class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                                data-toggle="tooltip" data-placement="top" title="Detail"><i
                                                   class="fa fa-eye"></i></a>

                                            <a href="<?php echo e(route('order.delete',$order->id)); ?>"
                                                class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                                onclick="return confirm('Bạn có muốn xoá đơn hàng này?')"
                                                data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                    class="fa fa-trash"></i></a>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan='7' class='bg-white'>Không tìm thấy khách hàng nào </td>
                                </tr>
                            <?php endif; ?>



                        </tbody>
                    </table>
                </form>

                <?php echo e($orders->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/unismart.com/resources/views/admin/order/list.blade.php ENDPATH**/ ?>