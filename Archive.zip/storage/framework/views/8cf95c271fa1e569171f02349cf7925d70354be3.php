<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="clearfix blog-page">
    <div class="wp-inner">
        <div class="secion" id="breadcrumb-wp">
            <div class="secion-detail">
                <ul class="list-item clearfix">
                    <li>
                        <a href="" title="">Trang chủ</a>
                    </li>
                    <li>
                        <a href="" title="">Bài viết</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-content fl-right">
            <div class="section" id="list-blog-wp">
                <div class="section-head clearfix">
                    <h3 class="section-title">Blog</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php if(isset($posts)): ?>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li class="clearfix">
                            <a href="<?php echo e(route('client.post.detail',$post->id)); ?>" title="" class="thumb fl-left">
                                <img width="250px" height="150px" src="<?php echo e(url("$post->thumb")); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="<?php echo e(route('client.post.detail',$post->id)); ?>" title="" class="title"><?php echo e($post->title); ?></a>
                                <span class="create-date"><?php echo e($post->created_at); ?></span>
                                <p class="desc"><?php echo $post->short_desc; ?></p>
                            </div>
                        </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php endif; ?>
                       
                       
                    </ul>
                </div>
            </div>
            
            <?php echo e($posts->links()); ?>

        </div>
    <?php echo $__env->make('client.inc.sidebar_post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/unismart.com/resources/views/client/post/list.blade.php ENDPATH**/ ?>