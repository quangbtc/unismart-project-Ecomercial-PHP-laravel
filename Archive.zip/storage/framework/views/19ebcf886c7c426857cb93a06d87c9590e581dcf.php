 <?php if($cate_parent->child->count()): ?>
    
         <ul class="sub-menu">
              <?php $__currentLoopData = $cate_parent->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li> <a href="<?php echo e(route('client.post.category.list',['slug'=>$children->slug,'id'=>$children->id])); ?>" title=""><?php echo e($children->cat_title); ?></a>
            <?php if($children->child->count()): ?>
            <?php echo $__env->make('client.inc.menu_child_post',['cate_parent'=>$children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
            <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </li>
         </ul>
    

 <?php endif; ?>
<?php /**PATH /Applications/MAMP/htdocs/unismart.com/resources/views/client/inc/menu_child_post.blade.php ENDPATH**/ ?>