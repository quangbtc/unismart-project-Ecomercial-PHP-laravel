<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="cart-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Đơn hàng</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="wrapper" class="wp-inner clearfix">
            <div class="section" id="info-cart-wp">
                 <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>
                <div class="section-detail table-responsive">
                    <?php if($order->count() > 0): ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>STT</td>
                                    <td>Mã đơn hàng</td>
                                    <td>Tên khách hàng</td>
                                    <td>Tổng tiền</td>
                                    <td>Thanh toán</td>
                                    <td>Trạng thái</td>
                                    <td>Ngày đặt</td>
                                    <td>Ghi chú</td>
                                    <td>Chi tiết</td>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td><?php echo e($order->code); ?></td>
                                    <td>
                                        <?php echo e($order->customer->full_name); ?>

                                    </td>
                                    <td>
                                        <?php echo e(number_format($order->total, 0, '', '.') . ' đ'); ?>

                                    </td>
                                    <td><?php echo e($order->payment); ?></td>
                                    <td>
                                        <?php echo e($order->status); ?>

                                    </td>
                                    <td><?php echo e($order->created_at); ?></td>
                                    <td><?php echo e($order->note); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('cart.detail',$order->id)); ?>" title="" class="detail"><i class="fa fa-eye"></i></a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/unismart.com/resources/views/client/cart/list.blade.php ENDPATH**/ ?>