<table align="center" bgcolor="#dcf0f8" border="0" cellpadding="0" cellspacing="0"
    style="margin:0;padding:0;background-color:#f2f2f2;width:100%!important;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px"
    width="100%">
    <tbody>
        <tr>
            <td align="center"
                style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal"
                valign="top">
                <table border="0" cellpadding="0" cellspacing="0" style="margin-top:15px" width="600">
                    <tbody>
                        <tr>
                            <td align="center" id="m_-358723594954361339headerImage" valign="bottom">
                                <table cellpadding="0" cellspacing="0"
                                    style="border-bottom:3px solid #00b7f1;padding-bottom:10px;background-color:#fff"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td align="center" bgcolor="#FFFFFF" style="padding:0" valign="top"
                                                width="100%">
                                                <a href="https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/1/ai2a1vXnOb046_uipJwu3w/aHR0cDovL3Rpa2kudm4vYXBwZG93bmxvYWQ_dXRtX3NvdXJjZT10cmFuc2FjdGlvbmFsK2VtYWlsJnV0bV9tZWRpdW09ZW1haWwmdXRtX3Rlcm09bG9nbyZ1dG1fY2FtcGFpZ249bmV3K29yZGVy"
                                                    style="border:medium none;text-decoration:none;color:#007ed3"
                                                    target="_blank"
                                                    data-saferedirecturl="https://www.google.com/url?q=https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/1/ai2a1vXnOb046_uipJwu3w/aHR0cDovL3Rpa2kudm4vYXBwZG93bmxvYWQ_dXRtX3NvdXJjZT10cmFuc2FjdGlvbmFsK2VtYWlsJnV0bV9tZWRpdW09ZW1haWwmdXRtX3Rlcm09bG9nbyZ1dG1fY2FtcGFpZ249bmV3K29yZGVy&amp;source=gmail&amp;ust=1619509558674000&amp;usg=AFQjCNGA2-CkYADirCtXZt9kKXlvUGWwlg">
                                                    <img alt="" height="40"
                                                        src="https://ci4.googleusercontent.com/proxy/lrppks7xzE6euW2045YpDJelaAHNnbav0B5_ZEIxDaODUkTKJWrN6G_WczSY9Gh_bKNFWt3Pr6HvFib3aMdGgduEsqqoDZ4=s0-d-e1-ft#http://tikicdn.com/media/custom/app_store_ios_2x.png"
                                                        style="height:40px;margin-top:17px" class="CToWUd"> <img alt=""
                                                        height="40"
                                                        src="https://ci5.googleusercontent.com/proxy/uY_osf13Vr_P4EHX7czu7re4LKf4PuBbvuSSTLV2NaP7JrNIOPGEOgv5IIBbzg_0Pwf6Uk92Ieu6jWKpEIzC8Mq-TEM=s0-d-e1-ft#http://tikicdn.com/media/custom/play_store_2x.png"
                                                        style="height:40px;margin:17px 20px 0px 20px" class="CToWUd">
                                                </a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr style="background:#fff">
                            <td align="left" height="auto" style="padding:15px" width="600">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                                    <tbody>
                                                        <tr>

                                                            <td><a href="https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/2/gDV_ZsOqD6nkvGPI_l1-ng/aHR0cHM6Ly90aWtpLnZuL2todXllbi1tYWkvdGlraXBybz9zcmM9b3JkZXJfY29uZmlybWF0aW9uX2VtYWls"
                                                                    style="display:inline-block;margin-bottom:20px"
                                                                    target="_blank"
                                                                    data-saferedirecturl="https://www.google.com/url?q=https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/2/gDV_ZsOqD6nkvGPI_l1-ng/aHR0cHM6Ly90aWtpLnZuL2todXllbi1tYWkvdGlraXBybz9zcmM9b3JkZXJfY29uZmlybWF0aW9uX2VtYWls&amp;source=gmail&amp;ust=1619509558675000&amp;usg=AFQjCNEgIJNRlnqEECwSJzV66Beb5XJbqA"><img
                                                                        alt=""
                                                                        src="https://ci6.googleusercontent.com/proxy/TM2_fvKXpt2CkV1m0Cu-ZjR-uNVLTYtq8PsdcACdtsXxyyPQKSNOFRuu-FkPCQ0ME9m6LKDpAKFLv4_6DWmYlUPiP_Rq-TfONJhW91Az8lj9Aof39_Tfk6kVXT81Lp-yoUJQ=s0-d-e1-ft#https://salt.tikicdn.com/ts/upload/e7/1c/92/61f328150099c5d13514e6845e6d306a.png"
                                                                        width="275" class="CToWUd"> </a></td>
                                                            <td><a href="https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/3/nOR2UUjKnuPS-IUnjGLLNw/aHR0cHM6Ly90aWtpLnZuL2RlYWwtaG90P3NyYz1vcmRlcl9jb25maXJtYXRpb25fZW1haWw"
                                                                    style="display:inline-block;margin-bottom:20px"
                                                                    target="_blank"
                                                                    data-saferedirecturl="https://www.google.com/url?q=https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/3/nOR2UUjKnuPS-IUnjGLLNw/aHR0cHM6Ly90aWtpLnZuL2RlYWwtaG90P3NyYz1vcmRlcl9jb25maXJtYXRpb25fZW1haWw&amp;source=gmail&amp;ust=1619509558675000&amp;usg=AFQjCNEBm3XJ9-z9k53yczhA1FX7MtdJRA"><img
                                                                        alt=""
                                                                        src="https://ci6.googleusercontent.com/proxy/KkM2PQvxEiOGefrFpVv72eJxBgU4Xe_Dl2RhXl04GF77FcRF6mw_fXdD5s4pIsO0Y-xk6h2PnaIqaNMLy75BZyUrf0dtJOxS8vrg8YE6vz21MQSYH2ASAKWiv_3XxQQ46R2p=s0-d-e1-ft#https://salt.tikicdn.com/ts/upload/f3/36/ea/c1a9c1b4cd58edd4b70067663e1fdb0d.png"
                                                                        width="275" class="CToWUd"> </a></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td>
                                                <h1
                                                    style="font-size:17px;font-weight:bold;color:#444;padding:0 0 5px 0;margin:0">
                                                    Cảm ơn quý khách <?php echo e($full_name); ?> đã đặt hàng tại Unismart,</h1>

                                                <p
                                                    style="margin:4px 0;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal">
                                                    Unismart rất vui thông báo đơn hàng của quý khách đã được
                                                    tiếp nhận và đang trong quá trình xử lý. Unismart sẽ thông báo đến
                                                    quý
                                                    khách ngay khi hàng chuẩn bị được giao.</p>

                                                <h3
                                                    style="font-size:13px;font-weight:bold;color:#02acea;text-transform:uppercase;margin:20px 0 0 0;border-bottom:1px solid #ddd">
                                                    Thông tin đơn hàng (<?php echo e($order->code); ?>)  <span
                                                        style="font-size:12px;color:#777;text-transform:none;font-weight:normal"><?php echo e($order->created_at); ?></span>
                                                </h3>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td
                                                style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px">
                                                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th align="left"
                                                                style="padding:6px 9px 0px 9px;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;font-weight:bold"
                                                                width="50%">Khách hàng </th>
                                                            <th align="left"
                                                                style="padding:6px 9px 0px 9px;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;font-weight:bold"
                                                                width="50%">Địa chỉ</th>
																 <th align="left"
                                                                style="padding:6px 9px 0px 9px;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;font-weight:bold"
                                                                width="50%">Email </th>
																 <th align="left"
                                                                style="padding:6px 9px 0px 9px;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;font-weight:bold"
                                                                width="50%">Số điện thoại </th>
																 <th align="left"
                                                                style="padding:6px 9px 0px 9px;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;font-weight:bold"
                                                                width="50%">Ngày đặt hàng </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td style="padding:3px 9px 9px 9px;border-top:0;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal"
                                                                valign="top"><span
                                                                    style="text-transform:capitalize"><?php echo e($full_name); ?></span><br>
                                                               
                                                            </td>
                                                           <td style="padding:3px 9px 9px 9px;border-top:0;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal"
                                                                valign="top"><span
                                                                    style="text-transform:capitalize"><?php echo e($address); ?></span><br>
                                                               
                                                            </td> 
															<td style="padding:3px 9px 9px 9px;border-top:0;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal"
                                                                valign="top"><span
                                                                    style="text-transform:capitalize"><?php echo e($email); ?></span><br>
                                                            </td>
															<td style="padding:3px 9px 9px 9px;border-top:0;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal"
                                                                valign="top"><span
                                                                    style="text-transform:capitalize"><?php echo e($phone); ?></span><br>
                                                            </td>
																<td style="padding:3px 9px 9px 9px;border-top:0;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal"
                                                                valign="top"><span
                                                                    style="text-transform:capitalize"><?php echo e($order->created_at); ?></span><br>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4"
                                                                style="padding:7px 9px 0px 9px;border-top:0;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444"
                                                                valign="top">
                                                                <p
                                                                    style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal">
                                                                    <strong>Phương thức thanh toán: </strong> <?php echo e($order->payment); ?>

                                                                    <br>
																	 <strong>Ghi chú: </strong> <?php echo e($order->note); ?>

                                                                    <br>
                                                                    <strong>Tình trạng đơn hàng:</strong><?php echo e($order->status); ?>

                                                                   <br>
                                                                    <strong>Phí vận chuyển: </strong> 14.000đ<br>
                                                                    <strong>Sử dụng bọc sách cao cấp Bookcare: </strong>
                                                                    Không <br>
                                                                </p>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <p
                                                    style="margin:4px 0;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal">
                                                    <i>Lưu ý: Đối với đơn hàng đã được thanh toán trước, nhân viên giao
                                                        nhận có thể yêu cầu người nhận hàng cung cấp CMND / giấy phép
                                                        lái xe để chụp ảnh hoặc ghi lại thông tin.</i>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <h2
                                                    style="text-align:left;margin:10px 0;border-bottom:1px solid #ddd;padding-bottom:5px;font-size:13px;color:#02acea">
                                                    CHI TIẾT ĐƠN HÀNG</h2>

                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    style="background:#f5f5f5" width="100%">
                                                    <thead>
                                                        <tr>
															 <th align="left" bgcolor="#02acea"
                                                                style="padding:6px 9px;color:#fff;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:14px">
                                                                STT</th>
                                                            <th align="left" bgcolor="#02acea"
                                                                style="padding:6px 9px;color:#fff;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:14px">
                                                                Sản phẩm</th>
                                                            <th align="left" bgcolor="#02acea"
                                                                style="padding:6px 9px;color:#fff;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:14px">
                                                                Hình ảnh</th>
                                                            <th align="left" bgcolor="#02acea"
                                                                style="padding:6px 9px;color:#fff;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:14px">
                                                                Đơn giá</th>
                                                            <th align="left" bgcolor="#02acea"
                                                                style="padding:6px 9px;color:#fff;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:14px">
                                                                Số lượng</th>
                                                            <th align="left" bgcolor="#02acea"
                                                                style="padding:6px 9px;color:#fff;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:14px">
                                                                Tổng </th>

                                                        </tr>
                                                    </thead>

                                                    <tbody bgcolor="#eee"
                                                        style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px">
                                                        <?php if($order): ?>
                                                            <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
																	  <td align="left" style="padding:3px 9px"
                                                                        valign="top">
                                                                        <span><?php echo e($loop->iteration); ?></span><br>
                                                                    </td>
                                                                    <td align="left" style="padding:3px 9px"
                                                                        valign="top">
                                                                        <span><?php echo e($product->title); ?></span><br>
                                                                    </td>

                                                                    <td align="left" style="padding:3px 9px"
                                                                        valign="top">
                                                                        <img width="30px" height="30px"
                                                                            src="<?php echo e(url("$product->thumb")); ?>"><br>
                                                                    </td>
                                                                    <td align="left" style="padding:3px 9px"
                                                                        valign="top">
                                                                        <span><?php echo e(number_format($product->pivot->price, '0', '', '.')); ?></span><br>
                                                                    </td>
                                                                    <td align="left" style="padding:3px 9px"
                                                                        valign="top">
                                                                        <span><?php echo e($product->pivot->qty); ?></span>
                                                                    </td>
                                                    
                                                                    <td align="left" style="padding:3px 9px"
                                                                        valign="top">
                                                                        <span><?php echo e(number_format($product->pivot->sub_total, '0', '', '.')); ?></span>
                                                                    </td>

                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>

                                                    </tbody>
                                                    <tfoot
                                                        style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px">
                                                        <tr>
                                                            <td align="left" style="padding:5px 9px" colspan="2">Tạm
                                                                tính :</td>
                                                            <td align="right" style="padding:5px 9px" colspan="4">
                                                                <span><?php echo e(number_format($order->total, '0', '', '.') . ' đ'); ?></span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="left" style="padding:5px 9px" colspan="2">Phí
                                                                vận chuyển</td>
                                                            <td align="right" style="padding:5px 9px" colspan="4">
                                                                <span><?php echo e($fee_ship); ?></span>
                                                            </td>
                                                        </tr>
                                                        <tr bgcolor="#eee">
                                                            <td align="left"  style="padding:7px 9px" colspan="2">
                                                                <strong><big>Tổng giá trị đơn hàng</big> </strong>
                                                            </td>
                                                            <td align="right" style="padding:7px 9px" colspan="4">
                                                                <strong><big><span><?php echo e(number_format($order->total + $fee_ship, '0', '', '.') . ' đ'); ?></span>
                                                                    </big> </strong>
                                                            </td>
                                                        </tr>
                                                    </tfoot>
                                                </table>

                                                <div style="margin:auto"><a
                                                        href="<?php echo e(url(route('cart.detail',$order->id))); ?>"
                                                        style="display:inline-block;text-decoration:none;background-color:#00b7f1!important;margin-right:30px;text-align:center;border-radius:3px;color:#fff;padding:5px 10px;font-size:12px;font-weight:bold;margin-left:35%;margin-top:5px"
                                                        target="_blank"
                                                        data-saferedirecturl="https://www.google.com/url?q=https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/4/uh0j5dfMyOEcOfIfKZUrmg/aHR0cHM6Ly90aWtpLnZuL3NhbGVzL29yZGVyL3ZpZXcvNjExODkwNTg2&amp;source=gmail&amp;ust=1619509558675000&amp;usg=AFQjCNF4UxFJdA70qJuRVjdrmH9tjf7QXQ">Chi
                                                        tiết đơn hàng tại Unismart</a></div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>&nbsp;
                                                <p
                                                    style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal">
                                                    Trường hợp quý khách có những băn khoăn về đơn hàng, có thể xem thêm
                                                    mục <a
                                                        href="https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/5/quabtN2vr6_IodMaUHYaRg/aHR0cDovL2hvdHJvLnRpa2kudm4vaGMvdmkvP3V0bV9zb3VyY2U9dHJhbnNhY3Rpb25hbCtlbWFpbCZ1dG1fbWVkaXVtPWVtYWlsJnV0bV90ZXJtPWxvZ28mdXRtX2NhbXBhaWduPW5ldytvcmRlcg"
                                                        title="Các câu hỏi thường gặp" target="_blank"
                                                        data-saferedirecturl="https://www.google.com/url?q=https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/5/quabtN2vr6_IodMaUHYaRg/aHR0cDovL2hvdHJvLnRpa2kudm4vaGMvdmkvP3V0bV9zb3VyY2U9dHJhbnNhY3Rpb25hbCtlbWFpbCZ1dG1fbWVkaXVtPWVtYWlsJnV0bV90ZXJtPWxvZ28mdXRtX2NhbXBhaWduPW5ldytvcmRlcg&amp;source=gmail&amp;ust=1619509558675000&amp;usg=AFQjCNEY1XqZ6SmnWidiFSnDpndYic64gg">
                                                        <strong>các câu hỏi thường gặp</strong>.</a></p>


                                                <p
                                                    style="margin:10px 0 0 0;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal">
                                                    Mọi thắc mắc và góp ý, quý khách vui lòng liên hệ với Unismart qua
                                                    <a href="https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/6/h46qmkiDpDdAwFbNzV7Hvw/aHR0cHM6Ly9ob3Ryby50aWtpLnZuL2hjL3Zp"
                                                        target="_blank"
                                                        data-saferedirecturl="https://www.google.com/url?q=https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/6/h46qmkiDpDdAwFbNzV7Hvw/aHR0cHM6Ly9ob3Ryby50aWtpLnZuL2hjL3Zp&amp;source=gmail&amp;ust=1619509558675000&amp;usg=AFQjCNEeAdbssvaQ8fwDVRXjwFu2ATPT7Q">https://hotro.tiki.vn/hc/vi</a>.
                                                    Đội ngũ Unismart luôn sẵn sàng hỗ trợ bạn.
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>&nbsp;
                                                <p
                                                    style="font-family:Arial,Helvetica,sans-serif;font-size:12px;margin:0;padding:0;line-height:18px;color:#444;font-weight:bold">
                                                    Một lần nữa Unismart cảm ơn quý khách.</p>

                                                <p
                                                    style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal;text-align:right">
                                                    <strong><a
                                                            href="https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/7/_4od4ivjiC9h9lDiM2qweA/aHR0cDovL3Rpa2kudm4_dXRtX3NvdXJjZT10cmFuc2FjdGlvbmFsK2VtYWlsJnV0bV9tZWRpdW09ZW1haWwmdXRtX3Rlcm09bG9nbyZ1dG1fY2FtcGFpZ249bmV3K29yZGVy"
                                                            style="color:#00a3dd;text-decoration:none;font-size:14px"
                                                            target="_blank"
                                                            data-saferedirecturl="https://www.google.com/url?q=https://x64km.mjt.lu/lnk/AMMAAJ1vmg8AAAAAAAAAADp_6bsAAAAA3NwAAAAAABPsQgBghm9ZJTAms2F9T-Knp0uEmQwHSwAPBhU/7/_4od4ivjiC9h9lDiM2qweA/aHR0cDovL3Rpa2kudm4_dXRtX3NvdXJjZT10cmFuc2FjdGlvbmFsK2VtYWlsJnV0bV9tZWRpdW09ZW1haWwmdXRtX3Rlcm09bG9nbyZ1dG1fY2FtcGFpZ249bmV3K29yZGVy&amp;source=gmail&amp;ust=1619509558675000&amp;usg=AFQjCNEzpWna9-UoH9lxUTsMYwkpM_jgug">Unismart</a>
                                                    </strong>
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td align="center">
                <table width="600">
                    <tbody>
                        <tr>
                            <td>
                                <p align="left"
                                    style="font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:18px;color:#4b8da5;padding:10px 0;margin:0px;font-weight:normal">
                                    Quý khách nhận được email này vì đã mua hàng tại Unismart.<br>
                                    Để chắc chắn luôn nhận được email thông báo, xác nhận mua hàng từ Unismart, quý khách
                                    vui lòng thêm địa chỉ <strong><a href="mailto:hotro@tiki.vn"
                                            target="_blank">hotro@tiki.vn</a></strong> vào số địa chỉ (Address Book,
                                    Contacts) của hộp email.<br>
                                   
                                    Bạn không muốn nhận email từ Unismart? Hủy đăng ký tại <a>đây</a>.
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
<?php /**PATH /Applications/MAMP/htdocs/unismart.com/resources/views/mail/order.blade.php ENDPATH**/ ?>